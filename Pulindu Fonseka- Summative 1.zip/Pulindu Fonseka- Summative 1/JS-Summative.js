// text pops up when a button is clicked 
let btn = document.getElementById('art');
/**
 * There is hidden text, when button is clicked, text shows up
 * works by there beig a variable "hidden", when it is removed, the text appears
 */
btn.addEventListener('click', ()=>{
    console.log('clicked')
    let txt = document.getElementById('art-txt');
    console.log(txt);
    if(txt.classList.contains('hidden')){
        console.log('showing')
        txt.classList.remove('hidden');
    }
    else{
        txt.classList.add('hidden');
    }
})
/**
 * 7) button for send/cancel
 * from:   https://www.youtube.com/watch?v=ikR9DsGMUMc
 * button-cancel clears the text box
 * button-send will send the data. will use this data at further date
 */
const init = function(){
    document.getElementById('button-cancel').addEventListener('click', reset);
    document.getElementById('button-send').addEventListener('click', send);
}
const reset = function(ev){
    ev.preventDefault();
    document.getElementById('form-user').reset();
}
const send = function(ev){
    ev.preventDefault();
    ev.stopPropagation();
    let ret = validate();
    if(ret){
        document.getElementById('form-user').submit();
        alert('Book review submitted! :) ');
    }else{
        let err = document.querySelector (' .error');
        let input = err.querySelector ('input');
        err.setAttribute ('data-errormsg', ` ...Missing${input.placeholder}`);
    }
}


// 8) following code used from https://www.chartjs.org/docs/latest/getting-started/

// import data_price from '.jsonData.json' assert {type: 'json'};
// console.log(data_price);
// const data = require('.jsonData.json');

var xmlhttp = new XMLHttpRequest();
var url = "jsonData.json";
xmlhttp.open("GET", url, true);
xmlhttp.send();
xmlhttp.onreadystatechange = function(){
    var data = JSON.parse(this.responseText);
    console.log(data)
}

/**
 * creates bar chart, price of paining on y axis, name of painting on x axis
 * scale relative to the data and y axis begins at zero
 */
const ctx = document.getElementById('paintChart').getContext('2d');
const myChart = new Chart(ctx, {
    type: 'bar',
     data: {
      labels: ['Salvator Mundi- Leonardo da Vinci', 'Interchange- Willem de Kooning', 'The Card Players- Paul Cezanne', 
      'Nafea Faa Ipoipo-Paul Gauguin- Paul Gauguin', 'Number 17A- Jackson Pollock', 'Wasserchlangen- Gustav Klimt', 'No.6- Mark Rothko', 
      'Pendant portrails of Maeten Soolmans and Oopjen Coppit- Rembrandit', 'Les Femmes dAlger- Pablo Picasso', 'The Strandard Bearer- Rembrandt'],
      datasets: [{
        label: 'price of painting (in million USD)',
        data: [497.8, 343, 301, 240, 229, 213.8, 213, 206, 205, 198],
        borderWidth: 1,
        backgroundColor: "#D2691E"
       }]
     },
     options: {
      scales: {
        y: {
          beginAtZero: true
        }
        }
      }
    });
    ///////////////////////////////////////////
    //