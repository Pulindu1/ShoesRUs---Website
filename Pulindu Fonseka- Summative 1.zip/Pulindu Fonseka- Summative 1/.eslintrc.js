module.exports = {
    extends: 'standard',
    rules: {
        semi: [2, 'always'],
        indent: 'off'
    },
    "settings":{
        "react":{
            "version": "detect"
        }
    }
};